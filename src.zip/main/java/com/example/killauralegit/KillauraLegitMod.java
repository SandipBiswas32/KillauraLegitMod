
package com.example.killauralegit;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public class KillauraLegitMod implements ClientModInitializer {
    private final MinecraftClient client = MinecraftClient.getInstance();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick());
    }

    private void tick() {
        if (client.player == null || client.world == null || client.currentScreen != null)
            return;

        double range = 4.25;
        Entity target = null;
        for (Entity entity : client.world.getEntities()) {
            if (entity == client.player || !(entity instanceof LivingEntity le)) continue;
            if (!entity.isAlive()) continue;
            if (client.player.distanceTo(entity) > range) continue;

            target = entity;
            break;
        }

        if (target != null && client.interactionManager != null) {
            client.interactionManager.attackEntity(client.player, target);
            client.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
